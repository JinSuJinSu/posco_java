package com.javaexam1202;

public class Exercise1 {
	
   public static void main(String[] args) {
	   
//	   다음에 제시된 세 개의 정수데이터(리터럴) 변수를 선언하여 저장하고 합계와 평균을 
//	   구하여 제시된 출력 형식과 같이 출력하는 프로그램을 작성하시오. 
//	   (평균의 소수 이하는 고려하지 않는다.)
//	   10, 25, 33
	   
//	   [ 출력 형식 ]
//
//	   합계 : 68
//	   평균 : 22
	   
	   int num1 = 10, num2 = 25, num3 = 33;
	   System.out.println("합계 : " + (num1 + num2 + num3));
	   System.out.println("평균 : " + (num1 + num2 + num3)/3);
}

}
