package com.javaexam1202;

public class Exercise4 {
	
   public static void main(String[] args) {
	   
	   
//	   실습 4(문제에서 요구되는 변수들외에는 추가로 선언하지 않는다.)
//
//	   1. int 타입의 변수 number 를 선언하고 100 이라는 값을 저장한다.
//	   2. int 타입의 변수 result 를 선언한다.
//
//	   3. number 변수의 값에 10을 더하고 결과를 result 에 담아 
//	      결과를 출력한다.    출력형식 : 덧셈 연산의 결과 - 110
//
//	   4. number 변수의 값에 10을 빼고 결과를 result 에 담아 
//	      결과를 출력한다.    출력형식 : 뺄셈 연산의 결과 - 90
//
//	   5. number 변수의 값에 10을 곱하고 결과를 result 에 담아 
//	      결과를 출력한다.    출력형식 : 곱셈 연산의 결과 - 1000
//
//	   6. number 변수의 값에 10을 나누고 결과를 result 에 담아 
//	      결과를 출력한다.	  출력형식 : 나눗셈 연산의 결과 - 10
	   
	  int number = 100;
	  int result;
	  
	  result=number+10;
	  System.out.println("덧셈 연산의 결과 - " + result);
	  
	  result=number-10;
	  System.out.println("뺄셈 연산의 결과 - " + result);
	  
	  result=number*10;
	  System.out.println("곱셈 연산의 결과 - " + result);
	  
	  result=number/10;
	  System.out.println("나눗셈 연산의 결과 - " + result);
	    
}

}
