package com.javaexam1204;

public class ForLab1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		1. ForLab1 이라는 클래스를 만든다.
//		2. 다음과 같은 결과가 출력되도록 구현한다.
//
//		    1 2 3 4 5 6 7 8 9 10
		
		for(int i=1; i<=10; i++) {
			System.out.print(i + " ");
		}

	}

}
