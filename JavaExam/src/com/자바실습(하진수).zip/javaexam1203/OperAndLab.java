package com.javaexam1203;

public class OperAndLab {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
